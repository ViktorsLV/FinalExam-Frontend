<template>
  <div>
    <h4 class="headlineLight--text">Graitor Points</h4>
    <v-card rounded="xl" elevation="5">
      <v-list class="rounded-xl">
        <v-list-item-group color="primary">
          <v-list-item two-line> 
            <v-list-item-content>
              <v-list-item-title class="secondary--text">
                <v-icon class="secondary--text">mdi-piggy-bank</v-icon>
                You will earn 70% in Graitor Points 
              </v-list-item-title
              >
              <v-list-item-subtitle class="ml-7">
                Use your Graitor Points to redeem treats!
              </v-list-item-subtitle
              >
            </v-list-item-content>
          </v-list-item>
          <!-- <v-divider></v-divider> -->
        </v-list-item-group>
      </v-list>
    </v-card>
  </div>
</template>

<script>

export default {  
};
</script>

<style>
</style>